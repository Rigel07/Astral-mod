package com.astral.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Cetro del Sol Naciente: pulso de luz que cura a aliados y mascotas y quema a los enemigos cercanos. */
public class SunScepterItem extends AstralWeaponItem {
    private static final double RADIUS = 8.0D;

    public SunScepterItem() {
        super("sun_scepter", 3.0D, -2.8D);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel serverLevel) {
            pulse(serverLevel, player);
        }
        player.getCooldowns().addCooldown(this, 200);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    private void pulse(ServerLevel level, Player player) {
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(RADIUS),
                LivingEntity::isAlive)) {
            boolean ally = entity instanceof Player
                    || (entity instanceof TamableAnimal pet && pet.isOwnedBy(player));
            if (ally) {
                entity.heal(8.0F);
                entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
                level.sendParticles(ParticleTypes.HEART, entity.getX(), entity.getY() + 1.4D, entity.getZ(),
                        4, 0.3D, 0.3D, 0.3D, 0.0D);
            } else if (entity instanceof Enemy) {
                entity.setSecondsOnFire(6);
                entity.hurt(level.damageSources().indirectMagic(player, player), entity.isInvertedHealAndHarm() ? 10.0F : 5.0F);
            }
        }
        for (int i = 0; i < 48; i++) {
            double angle = i * Math.PI * 2.0D / 48.0D;
            double x = player.getX() + Math.cos(angle) * RADIUS * 0.9D;
            double z = player.getZ() + Math.sin(angle) * RADIUS * 0.9D;
            level.sendParticles(ParticleTypes.FLAME, x, player.getY() + 0.3D, z, 1, 0.0D, 0.1D, 0.0D, 0.0D);
            level.sendParticles(ParticleTypes.END_ROD, x, player.getY() + 0.6D, z, 1, 0.0D, 0.2D, 0.0D, 0.02D);
        }
        level.sendParticles(ParticleTypes.FLASH, player.getX(), player.getY() + 1.0D, player.getZ(), 1, 0.0D, 0.0D, 0.0D, 0.0D);
        level.playSound(null, player.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.2F, 1.5F);
        level.playSound(null, player.blockPosition(), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 1.0F, 1.0F);
    }
}
