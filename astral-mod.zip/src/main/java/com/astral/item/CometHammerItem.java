package com.astral.item;

import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Martillo del Cometa: clic derecho te lanza al cielo; al caer con el en la mano, el impacto sacude el suelo. */
public class CometHammerItem extends AstralWeaponItem {
    public CometHammerItem() {
        super("comet_hammer", 9.0D, -3.2D);
    }

    public static boolean isHolding(Player player) {
        return player.getMainHandItem().getItem() instanceof CometHammerItem
                || player.getOffhandItem().getItem() instanceof CometHammerItem;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.onGround()) {
            Vec3 motion = player.getDeltaMovement();
            player.setDeltaMovement(motion.x, 1.15D, motion.z);
            player.hurtMarked = true;
            player.fallDistance = 0.0F;
            if (level instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY(), player.getZ(),
                        20, 0.5D, 0.1D, 0.5D, 0.1D);
                serverLevel.sendParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 0.2D, player.getZ(),
                        20, 0.4D, 0.1D, 0.4D, 0.2D);
                serverLevel.playSound(null, player.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 1.0F, 0.8F);
            }
            player.getCooldowns().addCooldown(this, 60);
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }
        return InteractionResultHolder.pass(stack);
    }

    /** Impacto en area: dano y radio crecen con la altura de la caida. */
    public static void slam(Player player, float fallDistance) {
        if (!(player.level() instanceof ServerLevel level)) {
            return;
        }
        float power = Math.min(fallDistance, 24.0F);
        double radius = 3.0D + power * 0.15D;
        float damage = 6.0F + power * 0.8F;
        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class,
                player.getBoundingBox().inflate(radius, 1.5D, radius), e -> isValidTarget(e, player));
        for (LivingEntity target : targets) {
            target.hurt(level.damageSources().playerAttack(player), damage);
            target.knockback(1.0D, player.getX() - target.getX(), player.getZ() - target.getZ());
            target.setDeltaMovement(target.getDeltaMovement().add(0.0D, 0.5D, 0.0D));
            target.hurtMarked = true;
        }
        int points = 36;
        for (int i = 0; i < points; i++) {
            double angle = i * Math.PI * 2.0D / points;
            double x = player.getX() + Math.cos(angle) * radius;
            double z = player.getZ() + Math.sin(angle) * radius;
            level.sendParticles(ParticleTypes.CRIT, x, player.getY() + 0.2D, z, 3, 0.1D, 0.1D, 0.1D, 0.1D);
            level.sendParticles(ParticleTypes.END_ROD, x, player.getY() + 0.4D, z, 1, 0.0D, 0.2D, 0.0D, 0.05D);
        }
        level.sendParticles(ParticleTypes.EXPLOSION, player.getX(), player.getY() + 0.3D, player.getZ(), 1, 0.0D, 0.0D, 0.0D, 0.0D);
        level.playSound(null, player.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.8F, 1.3F);
        level.playSound(null, player.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.8F, 0.7F);
    }
}
