package com.astral.item;

import java.util.List;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Baculo de la Estrella Fugaz: lanza una estrella que estalla en chispas magicas. */
public class StarStaffItem extends AstralWeaponItem {
    private static final double RANGE = 32.0D;
    private static final DustParticleOptions YELLOW = new DustParticleOptions(new Vector3f(1.0F, 0.9F, 0.3F), 1.2F);
    private static final DustParticleOptions PINK = new DustParticleOptions(new Vector3f(1.0F, 0.55F, 0.8F), 1.2F);

    public StarStaffItem() {
        super("star_staff", 2.0D, -2.8D);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel serverLevel) {
            fire(serverLevel, player);
        }
        player.getCooldowns().addCooldown(this, 30);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    private void fire(ServerLevel level, Player player) {
        Vec3 start = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 end = start.add(look.scale(RANGE));
        BlockHitResult blockHit = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        Vec3 limit = blockHit.getType() == HitResult.Type.MISS ? end : blockHit.getLocation();
        AABB box = player.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(1.0D);
        EntityHitResult entityHit = ProjectileUtil.getEntityHitResult(level, player, start, limit, box,
                e -> e instanceof LivingEntity living && isValidTarget(living, player));
        Vec3 impact = entityHit != null ? entityHit.getLocation() : limit;

        double distance = start.distanceTo(impact);
        int step = 0;
        for (double d = 1.0D; d < distance; d += 0.6D, step++) {
            Vec3 p = start.add(look.scale(d));
            level.sendParticles(step % 2 == 0 ? YELLOW : PINK, p.x, p.y, p.z, 1, 0.03D, 0.03D, 0.03D, 0.0D);
            if (step % 2 == 0) {
                level.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            }
        }
        level.sendParticles(ParticleTypes.FIREWORK, impact.x, impact.y, impact.z, 30, 0.5D, 0.5D, 0.5D, 0.12D);
        level.sendParticles(ParticleTypes.END_ROD, impact.x, impact.y, impact.z, 15, 0.4D, 0.4D, 0.4D, 0.1D);
        level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.7F);
        level.playSound(null, player.blockPosition(), SoundEvents.FIREWORK_ROCKET_TWINKLE, SoundSource.PLAYERS, 1.0F, 1.0F);

        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, new AABB(impact, impact).inflate(3.0D),
                e -> isValidTarget(e, player));
        for (LivingEntity target : targets) {
            boolean direct = entityHit != null && entityHit.getEntity() == target;
            target.hurt(level.damageSources().indirectMagic(player, player), direct ? 10.0F : 6.0F);
            target.knockback(0.5D, player.getX() - target.getX(), player.getZ() - target.getZ());
        }
    }
}
