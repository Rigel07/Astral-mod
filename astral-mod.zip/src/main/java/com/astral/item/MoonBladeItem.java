package com.astral.item;

import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Espada de la Luna Creciente: cada golpe ralentiza y marca al enemigo; clic derecho = tajo lunar (embestida). */
public class MoonBladeItem extends AstralWeaponItem {
    public MoonBladeItem() {
        super("moon_blade", 6.0D, -2.4D);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
        target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0));
        return true;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        Vec3 dir = Vec3.directionFromRotation(0.0F, player.getYRot()).normalize();
        player.setDeltaMovement(dir.x * 2.4D, 0.12D, dir.z * 2.4D);
        player.hurtMarked = true;
        player.fallDistance = 0.0F;

        if (level instanceof ServerLevel serverLevel) {
            AABB path = player.getBoundingBox().expandTowards(dir.scale(5.0D)).inflate(1.0D);
            List<LivingEntity> targets = serverLevel.getEntitiesOfClass(LivingEntity.class, path,
                    e -> isValidTarget(e, player));
            for (LivingEntity target : targets) {
                target.hurt(serverLevel.damageSources().playerAttack(player), 8.0F);
                target.knockback(0.8D, -dir.x, -dir.z);
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
            }
            for (int i = 0; i < 8; i++) {
                Vec3 p = player.position().add(dir.scale(i * 0.7D)).add(0.0D, 1.0D, 0.0D);
                serverLevel.sendParticles(ParticleTypes.SWEEP_ATTACK, p.x, p.y, p.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
                serverLevel.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 2, 0.2D, 0.3D, 0.2D, 0.02D);
            }
            serverLevel.playSound(null, player.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.2F, 1.4F);
            serverLevel.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 0.8F);
        }
        player.getCooldowns().addCooldown(this, 80);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
