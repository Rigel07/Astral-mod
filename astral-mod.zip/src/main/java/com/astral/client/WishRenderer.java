package com.astral.client;

import com.astral.AstralMod;
import com.astral.wish.WishEntity;
import com.astral.wish.WishKind;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Dibuja el deseo como una gota luminosa que siempre mira a la camara y brilla al maximo. */
public class WishRenderer extends EntityRenderer<WishEntity> {
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[WishKind.values().length];

    static {
        for (WishKind kind : WishKind.values()) {
            TEXTURES[kind.ordinal()] = new ResourceLocation(AstralMod.MODID, "textures/entity/wish_" + kind.id() + ".png");
        }
    }

    public WishRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public ResourceLocation getTextureLocation(WishEntity entity) {
        return TEXTURES[entity.getKind().ordinal()];
    }

    @Override
    public void render(WishEntity entity, float entityYaw, float partialTicks, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        WishKind kind = entity.getKind();
        float scale = kind.rare ? 1.7F : 1.2F;
        float pulse = 1.0F + (float) Math.sin((entity.tickCount + partialTicks) * 0.3F) * 0.08F;
        poseStack.pushPose();
        poseStack.translate(0.0D, 0.25D, 0.0D);
        poseStack.scale(scale * pulse, scale * pulse, scale * pulse);
        poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F));
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        Matrix3f normal = pose.normal();
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityTranslucent(this.getTextureLocation(entity)));
        int light = LightTexture.FULL_BRIGHT;
        vertex(consumer, matrix, normal, light, 0.0F, 0, 0, 1);
        vertex(consumer, matrix, normal, light, 1.0F, 0, 1, 1);
        vertex(consumer, matrix, normal, light, 1.0F, 1, 1, 0);
        vertex(consumer, matrix, normal, light, 0.0F, 1, 0, 0);
        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    private static void vertex(VertexConsumer consumer, Matrix4f matrix, Matrix3f normal, int light,
                               float x, int y, int u, int v) {
        consumer.vertex(matrix, x - 0.5F, (float) y - 0.25F, 0.0F)
                .color(255, 255, 255, 255)
                .uv((float) u, (float) v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(normal, 0.0F, 1.0F, 0.0F)
                .endVertex();
    }
}
