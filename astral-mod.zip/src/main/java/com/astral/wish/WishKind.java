package com.astral.wish;

import com.astral.registry.ModEffects;
import com.astral.registry.ModItems;
import java.util.Locale;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.item.Item;

/** Los seis deseos. Verde, rojo, amarillo y violeta son comunes; dorado y oscuro son raros, rapidos y esquivos. */
public enum WishKind {
    GREEN(0.35F, 1.00F, 0.45F, false, 0.17D, 12000, 24),
    RED(1.00F, 0.25F, 0.25F, false, 0.17D, 12000, 24),
    YELLOW(1.00F, 0.90F, 0.30F, false, 0.20D, 12000, 24),
    VIOLET(0.70F, 0.40F, 1.00F, false, 0.17D, 12000, 18),
    GOLD(1.00F, 0.78F, 0.15F, true, 0.40D, 18000, 6),
    DARK(0.35F, 0.10F, 0.50F, true, 0.40D, 18000, 6);

    public final float r;
    public final float g;
    public final float b;
    public final boolean rare;
    public final double fallSpeed;
    public final int durationTicks;
    public final int weight;

    WishKind(float r, float g, float b, boolean rare, double fallSpeed, int durationTicks, int weight) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.rare = rare;
        this.fallSpeed = fallSpeed;
        this.durationTicks = durationTicks;
        this.weight = weight;
    }

    public String id() {
        return name().toLowerCase(Locale.ROOT);
    }

    public MobEffect effect() {
        return switch (this) {
            case GREEN -> ModEffects.GREEN.get();
            case RED -> ModEffects.RED.get();
            case YELLOW -> ModEffects.YELLOW.get();
            case VIOLET -> ModEffects.VIOLET.get();
            case GOLD -> ModEffects.GOLD.get();
            case DARK -> ModEffects.DARK.get();
        };
    }

    public Item essence() {
        return switch (this) {
            case GREEN -> ModItems.ESSENCE_GREEN.get();
            case RED -> ModItems.ESSENCE_RED.get();
            case YELLOW -> ModItems.ESSENCE_YELLOW.get();
            case VIOLET -> ModItems.ESSENCE_VIOLET.get();
            case GOLD -> ModItems.ESSENCE_GOLD.get();
            case DARK -> ModItems.ESSENCE_DARK.get();
        };
    }

    public static WishKind byOrdinal(int ordinal) {
        WishKind[] all = values();
        return all[Math.floorMod(ordinal, all.length)];
    }

    public static WishKind byId(String id) {
        for (WishKind kind : values()) {
            if (kind.id().equals(id)) {
                return kind;
            }
        }
        return null;
    }
}
