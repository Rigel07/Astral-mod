package com.astral.wish;

import com.astral.AstralMod;
import com.astral.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Hace caer deseos del cielo cerca de los jugadores del Overworld. */
@Mod.EventBusSubscriber(modid = AstralMod.MODID)
public final class WishSpawner {
    /** Un deseo cada 240 s de media por jugador (se comprueba una vez por segundo). */
    private static final int CHANCE_PER_SECOND = 240;
    private static final int FALL_HEIGHT = 45;

    private WishSpawner() {}

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.level.isClientSide()
                || !(event.level instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD
                || level.getGameTime() % 20L != 0L) {
            return;
        }
        for (ServerPlayer player : level.players()) {
            if (player.isSpectator() || level.random.nextInt(CHANCE_PER_SECOND) != 0) {
                continue;
            }
            int nearby = level.getEntitiesOfClass(WishEntity.class, new AABB(player.blockPosition()).inflate(64.0D)).size();
            if (nearby >= 2) {
                continue;
            }
            WishKind kind = pickKind(level);
            spawnNear(level, player, kind);
        }
    }

    private static boolean isDay(ServerLevel level) {
        return level.getDayTime() % 24000L < 12000L;
    }

    /** Eleccion ponderada: el dorado solo cae de dia y el oscuro solo de noche. */
    private static WishKind pickKind(ServerLevel level) {
        boolean day = isDay(level);
        int total = 0;
        for (WishKind kind : WishKind.values()) {
            total += weightOf(kind, day);
        }
        int roll = level.random.nextInt(total);
        for (WishKind kind : WishKind.values()) {
            roll -= weightOf(kind, day);
            if (roll < 0) {
                return kind;
            }
        }
        return WishKind.GREEN;
    }

    private static int weightOf(WishKind kind, boolean day) {
        if (kind == WishKind.GOLD && !day) {
            return 0;
        }
        if (kind == WishKind.DARK && day) {
            return 0;
        }
        return kind.weight;
    }

    private static void spawnNear(ServerLevel level, ServerPlayer player, WishKind kind) {
        RandomSource random = level.random;
        double angle = random.nextDouble() * Math.PI * 2.0D;
        double distance = 6.0D + random.nextDouble() * 14.0D;
        int x = (int) Math.floor(player.getX() + Math.cos(angle) * distance);
        int z = (int) Math.floor(player.getZ() + Math.sin(angle) * distance);
        if (!level.hasChunkAt(new BlockPos(x, player.getBlockY(), z))) {
            return;
        }
        int ground = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        int y = Math.min(level.getMaxBuildHeight() - 5, Math.max(player.getBlockY(), ground) + FALL_HEIGHT);
        spawn(level, kind, x + 0.5D, y, z + 0.5D);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.AMETHYST_BLOCK_RESONATE,
                SoundSource.AMBIENT, 2.0F, kind.rare ? 0.7F : 1.5F);
        if (kind.rare) {
            player.displayClientMessage(Component.translatable("message.astral.wish_rare_falling." + kind.id()), true);
        }
    }

    public static WishEntity spawn(ServerLevel level, WishKind kind, double x, double y, double z) {
        WishEntity wish = ModEntities.WISH.get().create(level);
        if (wish == null) {
            return null;
        }
        wish.setKind(kind);
        wish.moveTo(x, y, z, 0.0F, 0.0F);
        level.addFreshEntity(wish);
        return wish;
    }
}
