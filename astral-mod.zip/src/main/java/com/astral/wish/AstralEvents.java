package com.astral.wish;

import com.astral.AstralMod;
import com.astral.block.AstralLightBlock;
import com.astral.item.CometHammerItem;
import com.astral.registry.ModEffects;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

/** Efectos que dependen de eventos: robo de vida oscuro, estela de luz y el impacto del martillo. */
@Mod.EventBusSubscriber(modid = AstralMod.MODID)
public final class AstralEvents {
    private AstralEvents() {}

    /** Pacto oscuro: cura el 30 % del dano que inflige. */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        if (event.getEntity().level().isClientSide()) {
            return;
        }
        if (event.getSource().getEntity() instanceof LivingEntity attacker && attacker != event.getEntity()
                && attacker.hasEffect(ModEffects.DARK.get())) {
            attacker.heal(event.getAmount() * 0.3F);
        }
    }

    /** Amarillo y dorado: dejan una estela de luz por donde pasan. */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER
                || event.player.tickCount % 4 != 0) {
            return;
        }
        Player player = event.player;
        boolean gold = player.hasEffect(ModEffects.GOLD.get());
        if (!gold && !player.hasEffect(ModEffects.YELLOW.get())) {
            return;
        }
        Level level = player.level();
        BlockPos pos = player.blockPosition().above();
        if (!level.getBlockState(pos).isAir()) {
            pos = player.blockPosition();
        }
        AstralLightBlock.place(level, pos, gold ? 14 : 11);
    }

    /** Martillo del cometa: caer con el en la mano provoca un impacto en area y anula el dano de la caida. */
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (!(event.getEntity() instanceof Player player) || player.level().isClientSide()) {
            return;
        }
        if (event.getDistance() > 3.0F && CometHammerItem.isHolding(player)) {
            CometHammerItem.slam(player, event.getDistance());
            event.setDamageMultiplier(0.0F);
        }
    }
}
