package com.astral.wish;

import com.astral.AstralMod;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Arrays;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** /astral wish <green|red|yellow|violet|gold|dark>: hace caer un deseo sobre ti (solo operadores, para probar). */
@Mod.EventBusSubscriber(modid = AstralMod.MODID)
public final class WishCommands {
    private WishCommands() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("astral")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("wish")
                        .then(Commands.argument("color", StringArgumentType.word())
                                .suggests((context, builder) -> SharedSuggestionProvider.suggest(
                                        Arrays.stream(WishKind.values()).map(WishKind::id), builder))
                                .executes(WishCommands::wish))));
    }

    private static int wish(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        String color = StringArgumentType.getString(context, "color");
        WishKind kind = WishKind.byId(color);
        if (kind == null) {
            context.getSource().sendFailure(Component.translatable("message.astral.command_unknown", color));
            return 0;
        }
        ServerPlayer player = context.getSource().getPlayerOrException();
        WishSpawner.spawn(player.serverLevel(), kind, player.getX(), player.getY() + 22.0D, player.getZ());
        context.getSource().sendSuccess(() -> Component.translatable("message.astral.command_ok",
                Component.translatable("wish.astral." + kind.id())), true);
        return 1;
    }
}
