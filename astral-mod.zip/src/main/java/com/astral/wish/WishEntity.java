package com.astral.wish;

import com.astral.block.AstralLightBlock;
import java.util.List;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;
import org.joml.Vector3f;

/**
 * Un deseo: una gota de luz que cae del cielo. Si cae sobre un jugador, le concede su poder;
 * si llega al suelo sin tocar a nadie, se deshace y deja una esencia.
 */
public class WishEntity extends Entity {
    private static final EntityDataAccessor<Integer> DATA_KIND =
            SynchedEntityData.defineId(WishEntity.class, EntityDataSerializers.INT);

    private int age;

    public WishEntity(EntityType<? extends WishEntity> type, Level level) {
        super(type, level);
        this.noPhysics = false;
        this.setNoGravity(true);
    }

    public WishKind getKind() {
        return WishKind.byOrdinal(this.entityData.get(DATA_KIND));
    }

    public void setKind(WishKind kind) {
        this.entityData.set(DATA_KIND, kind.ordinal());
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DATA_KIND, 0);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.entityData.set(DATA_KIND, tag.getInt("Kind"));
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Kind", this.entityData.get(DATA_KIND));
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        WishKind kind = this.getKind();

        if (this.level().isClientSide) {
            spawnTrail(kind);
            return;
        }

        this.age++;
        double dx = 0.0D;
        double dz = 0.0D;
        if (kind.rare) {
            // los deseos dorado y oscuro zigzaguean: hay que perseguirlos
            dx = Math.sin(this.age * 0.35D) * 0.16D;
            dz = Math.cos(this.age * 0.27D) * 0.16D;
        }
        this.setDeltaMovement(dx, -kind.fallSpeed, dz);
        this.move(MoverType.SELF, this.getDeltaMovement());

        List<Player> players = this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(0.35D),
                p -> p.isAlive() && !p.isSpectator());
        if (!players.isEmpty()) {
            grant(players.get(0), kind);
            this.discard();
            return;
        }

        if (this.age % 3 == 0) {
            AstralLightBlock.place(this.level(), this.blockPosition(), 13);
        }

        if (this.onGround() || this.isInWater() || this.age > 1500) {
            fizzle(kind);
        }
    }

    private void spawnTrail(WishKind kind) {
        DustParticleOptions dust = new DustParticleOptions(new Vector3f(kind.r, kind.g, kind.b), kind.rare ? 1.6F : 1.2F);
        for (int i = 0; i < 2; i++) {
            this.level().addParticle(dust,
                    this.getX() + (this.random.nextDouble() - 0.5D) * 0.35D,
                    this.getY() + 0.2D + this.random.nextDouble() * 0.5D,
                    this.getZ() + (this.random.nextDouble() - 0.5D) * 0.35D,
                    0.0D, 0.0D, 0.0D);
        }
        if (this.random.nextInt(2) == 0) {
            this.level().addParticle(ParticleTypes.END_ROD, this.getX(), this.getY() + 0.5D, this.getZ(),
                    0.0D, 0.04D, 0.0D);
        }
        if (kind.rare && this.random.nextInt(3) == 0) {
            this.level().addParticle(kind == WishKind.DARK ? ParticleTypes.SQUID_INK : ParticleTypes.GLOW,
                    this.getX() + (this.random.nextDouble() - 0.5D), this.getY() + 0.3D,
                    this.getZ() + (this.random.nextDouble() - 0.5D), 0.0D, 0.02D, 0.0D);
        }
    }

    private void grant(Player player, WishKind kind) {
        player.addEffect(new MobEffectInstance(kind.effect(), kind.durationTicks, 0, false, true, true));
        player.displayClientMessage(Component.translatable("message.astral.wish_" + kind.id()), true);
        if (this.level() instanceof ServerLevel level) {
            level.playSound(null, player.blockPosition(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1.0F, 1.2F);
            level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.5F, 0.9F);
            level.sendParticles(new DustParticleOptions(new Vector3f(kind.r, kind.g, kind.b), 1.5F),
                    player.getX(), player.getY() + 1.0D, player.getZ(), 50, 0.5D, 0.9D, 0.5D, 0.02D);
            level.sendParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0D, player.getZ(),
                    20, 0.4D, 0.8D, 0.4D, 0.05D);
            if (kind.rare && player instanceof ServerPlayer serverPlayer) {
                serverPlayer.server.getPlayerList().broadcastSystemMessage(
                        Component.translatable("message.astral.wish_broadcast", player.getDisplayName(),
                                Component.translatable("wish.astral." + kind.id())), false);
            }
        }
    }

    private void fizzle(WishKind kind) {
        if (this.level() instanceof ServerLevel level) {
            level.sendParticles(new DustParticleOptions(new Vector3f(kind.r, kind.g, kind.b), 1.3F),
                    this.getX(), this.getY() + 0.2D, this.getZ(), 24, 0.35D, 0.2D, 0.35D, 0.04D);
            level.playSound(null, this.blockPosition(), SoundEvents.AMETHYST_BLOCK_BREAK, SoundSource.AMBIENT, 1.0F, 1.4F);
            ItemEntity essence = new ItemEntity(level, this.getX(), this.getY() + 0.3D, this.getZ(),
                    new ItemStack(kind.essence()));
            essence.setDeltaMovement(0.0D, 0.15D, 0.0D);
            level.addFreshEntity(essence);
        }
        this.discard();
    }
}
