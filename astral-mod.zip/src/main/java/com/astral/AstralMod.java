package com.astral;

import com.astral.registry.ModBlocks;
import com.astral.registry.ModCreativeTabs;
import com.astral.registry.ModEffects;
import com.astral.registry.ModEntities;
import com.astral.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(AstralMod.MODID)
public class AstralMod {
    public static final String MODID = "astral";

    public AstralMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITY_TYPES.register(modBus);
        ModEffects.EFFECTS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
    }
}
