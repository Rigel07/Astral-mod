package com.astral.registry;

import com.astral.AstralMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AstralMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("astral",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.astral"))
                    .icon(() -> new ItemStack(ModItems.STAR_STAFF.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.STAR_STAFF.get());
                        output.accept(ModItems.MOON_BLADE.get());
                        output.accept(ModItems.SUN_SCEPTER.get());
                        output.accept(ModItems.COMET_HAMMER.get());
                        output.accept(ModItems.ESSENCE_GREEN.get());
                        output.accept(ModItems.ESSENCE_RED.get());
                        output.accept(ModItems.ESSENCE_YELLOW.get());
                        output.accept(ModItems.ESSENCE_VIOLET.get());
                        output.accept(ModItems.ESSENCE_GOLD.get());
                        output.accept(ModItems.ESSENCE_DARK.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
