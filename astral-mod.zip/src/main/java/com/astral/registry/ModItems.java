package com.astral.registry;

import com.astral.AstralMod;
import com.astral.item.CometHammerItem;
import com.astral.item.MoonBladeItem;
import com.astral.item.StarStaffItem;
import com.astral.item.SunScepterItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, AstralMod.MODID);

    // --- las cuatro armas del astral
    public static final RegistryObject<Item> STAR_STAFF = ITEMS.register("star_staff", StarStaffItem::new);
    public static final RegistryObject<Item> MOON_BLADE = ITEMS.register("moon_blade", MoonBladeItem::new);
    public static final RegistryObject<Item> SUN_SCEPTER = ITEMS.register("sun_scepter", SunScepterItem::new);
    public static final RegistryObject<Item> COMET_HAMMER = ITEMS.register("comet_hammer", CometHammerItem::new);

    // --- esencias que dejan los deseos que caen sin tocar a nadie
    public static final RegistryObject<Item> ESSENCE_GREEN = essence("wish_essence_green", Rarity.COMMON);
    public static final RegistryObject<Item> ESSENCE_RED = essence("wish_essence_red", Rarity.COMMON);
    public static final RegistryObject<Item> ESSENCE_YELLOW = essence("wish_essence_yellow", Rarity.COMMON);
    public static final RegistryObject<Item> ESSENCE_VIOLET = essence("wish_essence_violet", Rarity.COMMON);
    public static final RegistryObject<Item> ESSENCE_GOLD = essence("wish_essence_gold", Rarity.EPIC);
    public static final RegistryObject<Item> ESSENCE_DARK = essence("wish_essence_dark", Rarity.EPIC);

    private ModItems() {}

    private static RegistryObject<Item> essence(String name, Rarity rarity) {
        return ITEMS.register(name, () -> new Item(new Item.Properties().rarity(rarity)));
    }
}
