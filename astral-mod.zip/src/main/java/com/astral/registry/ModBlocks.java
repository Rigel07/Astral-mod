package com.astral.registry;

import com.astral.AstralMod;
import com.astral.block.AstralLightBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, AstralMod.MODID);

    /** Bloque de luz invisible y temporal: lo dejan los deseos al caer y quien tiene el poder amarillo o dorado. */
    public static final RegistryObject<Block> ASTRAL_LIGHT = BLOCKS.register("astral_light",
            () -> new AstralLightBlock(BlockBehaviour.Properties.of()
                    .replaceable()
                    .noCollission()
                    .noOcclusion()
                    .strength(-1.0F, 3600000.8F)
                    .lightLevel(state -> state.getValue(AstralLightBlock.LEVEL))
                    .pushReaction(PushReaction.DESTROY)));

    private ModBlocks() {}
}
