package com.astral.registry;

import com.astral.AstralMod;
import com.astral.wish.WishEffect;
import com.astral.wish.WishKind;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Los poderes que concede cada deseo. */
public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, AstralMod.MODID);

    public static final RegistryObject<MobEffect> GREEN = EFFECTS.register("wish_green",
            () -> new WishEffect(WishKind.GREEN, 0x59FF73));
    public static final RegistryObject<MobEffect> RED = EFFECTS.register("wish_red",
            () -> new WishEffect(WishKind.RED, 0xFF4040));
    public static final RegistryObject<MobEffect> YELLOW = EFFECTS.register("wish_yellow",
            () -> new WishEffect(WishKind.YELLOW, 0xFFE64D));
    public static final RegistryObject<MobEffect> VIOLET = EFFECTS.register("wish_violet",
            () -> new WishEffect(WishKind.VIOLET, 0xB366FF));
    public static final RegistryObject<MobEffect> GOLD = EFFECTS.register("wish_gold",
            () -> new WishEffect(WishKind.GOLD, 0xFFC726));
    public static final RegistryObject<MobEffect> DARK = EFFECTS.register("wish_dark",
            () -> new WishEffect(WishKind.DARK, 0x59198A));

    private ModEffects() {}
}
