package com.astral.block;

import com.astral.registry.ModBlocks;
import com.astral.registry.ModEffects;
import com.astral.wish.WishEntity;
import java.util.Collections;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Luz invisible que se queda mientras haya un deseo cayendo o alguien con poder amarillo/dorado cerca. */
public class AstralLightBlock extends Block {
    public static final IntegerProperty LEVEL = BlockStateProperties.LEVEL;
    public static final int RECHECK_TICKS = 15;

    public AstralLightBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(LEVEL, 12));
    }

    /** Coloca una luz temporal en una celda de aire. */
    public static void place(Level level, BlockPos pos, int lightLevel) {
        if (level.getBlockState(pos).isAir()) {
            level.setBlock(pos, ModBlocks.ASTRAL_LIGHT.get().defaultBlockState().setValue(LEVEL, lightLevel), 3);
        }
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LEVEL);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    public boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
        return true;
    }

    @Override
    public float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
        return 1.0F;
    }

    @Override
    public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
        return Collections.emptyList();
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        if (!level.isClientSide) {
            level.scheduleTick(pos, this, RECHECK_TICKS);
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        boolean keep = !level.getEntitiesOfClass(Entity.class, new AABB(pos).inflate(1.5D),
                AstralLightBlock::emitsLight).isEmpty();
        if (keep) {
            level.scheduleTick(pos, this, RECHECK_TICKS);
        } else {
            level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
        }
    }

    private static boolean emitsLight(Entity entity) {
        if (entity instanceof WishEntity) {
            return true;
        }
        return entity instanceof LivingEntity living
                && (living.hasEffect(ModEffects.YELLOW.get()) || living.hasEffect(ModEffects.GOLD.get()));
    }
}
