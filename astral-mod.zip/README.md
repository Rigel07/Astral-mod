# Armas del Astral (Forge 1.20.1)

Mod para Minecraft Forge 1.20.1 (Forge 47.2.0, Java 17): **cuatro reliquias sagradas cute** y **Los Deseos**, almas antiguas que caen del cielo y dan poder al jugador que reciben.

## Los Deseos
Caen del cielo como una gota que brilla de su color (cerca de ti, a unos 45 bloques de altura, de media uno cada 4 minutos). **Ponte debajo**: si te cae encima, te concede su poder (el nombre del efecto sale en tu pantalla de efectos).

| Deseo | Dura | Poder |
|---|---|---|
| **Verde** | 10 min | +4 corazones, regeneras cada segundo, hace crecer los cultivos cercanos y cura a los animales. |
| **Rojo** | 10 min | +4 de ataque, +4 de armadura, resistencia al empuje, inmune al fuego y un aura que **prende fuego a los enemigos** cercanos. |
| **Amarillo** | 10 min | +50 % velocidad y de ataque, visión nocturna, salto alto y **deja luz por donde pasas**. |
| **Violeta** | 10 min | Caída lenta, saltos enormes y un **radar** que hace brillar a todos los seres vivos a 24 bloques. |
| **Dorado** *(raro, solo de día)* | 15 min | +10 corazones, +6 de ataque, +8 de armadura, +4 de dureza, suerte, +20 % velocidad, regeneración, limpia los efectos malos y deja luz. |
| **Oscuro** *(raro, solo de noche)* | 15 min | +9 de ataque, +40 % velocidad de ataque, +30 % velocidad, visión nocturna, **roba el 30 % del daño que haces** como vida y frena a los enemigos cercanos… pero **pierdes 4 corazones**. |

Los deseos dorado y oscuro son los más complicados: caen **el doble de rápido y zigzaguean**, así que hay que perseguirlos. Cuando alguien recibe uno, se avisa a todo el servidor.

Si un deseo llega al suelo sin tocar a nadie, se deshace y deja una **Esencia de Deseo** de su color.

## Las armas del astral (reliquias sagradas)
Indestructibles, con brillo y habilidad con clic derecho. Se fabrican **sin forma** (cualquier colocación) con esencias:

| Arma | Habilidad | Receta |
|---|---|---|
| **Báculo de la Estrella Fugaz** | Lanza una estrella que estalla en chispas y daña en área (10 daño directo, 6 alrededor). Enfriamiento 1,5 s. | esencia dorada + 2 violeta + 2 amarilla + 2 fragmentos de amatista + 1 palo |
| **Espada de la Luna Creciente** | Tajo lunar: embestida que corta todo a su paso. Cada golpe ralentiza y marca (brillo) al enemigo. Enfriamiento 4 s. | esencia oscura + 2 violeta + espada de diamante + 2 fragmentos de amatista |
| **Cetro del Sol Naciente** | Pulso solar: cura 4 corazones a jugadores y mascotas a 8 bloques y quema a los enemigos. Enfriamiento 10 s. | esencia dorada + 2 amarilla + 2 roja + vara de blaze + 2 polvo de piedra luminosa |
| **Martillo del Cometa** | Clic derecho: te lanza al cielo. Al caer con él en la mano, el impacto daña y lanza a los enemigos (más daño y radio cuanto más alto caes) y **no recibes daño de caída**. | esencia oscura + 2 roja + 2 verde + bloque de hierro + 1 palo |

Las esencias dorada y oscura son las más difíciles de conseguir: solo salen de los deseos raros que llegan al suelo.

## Comandos (operadores)
- `/astral wish <green|red|yellow|violet|gold|dark>`: hace caer un deseo sobre ti (para probar).
- `/give @s astral:wish_essence_gold` y demás para tener esencias; las armas están en la pestaña creativa "Armas del Astral".

## Ajustes
- Frecuencia: `CHANCE_PER_SECOND` en `WishSpawner.java` (240 = uno cada 4 min por jugador).
- Pesos de cada color y velocidades: `WishKind.java`.
- Potencia de los poderes: `WishEffect.java`.

## Compilar con GitHub (sin instalar nada)
1. Sube a un repositorio **este .zip tal cual** (sin descomprimir) y el archivo `.github/workflows/build.yml`
   (créalo con *Add file → Create new file* escribiendo la ruta `.github/workflows/build.yml`).
2. GitHub descomprime el zip, compila y deja el `.jar` en **Actions → último run → Artifacts → mod-jar**.
3. Copia el `.jar` a la carpeta `mods` de Forge 1.20.1.

Compilar en local: `gradle build` (Gradle 8.1.1, JDK 17). El jar queda en `build/libs/`.
